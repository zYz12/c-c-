#include<graphics.h>
#include<iostream>
#include<conio.h>

int Map00[8][10]{
	1,1,1,1,1,1,1,1,1,1,
	1,0,0,0,0,0,0,0,0,1,
	1,0,1,1,1,1,1,1,0,1,
	1,0,0,0,1,4,4,4,0,1,
	1,0,2,2,1,1,1,0,0,1,
	1,0,2,0,0,0,0,0,0,1,
	1,0,3,0,0,0,0,0,0,1,
	1,1,1,1,1,1,1,1,1,1
};
int Map01[8][10]{
	1,1,1,1,1,1,1,1,1,1,
	1,0,0,0,0,0,0,0,3,1,
	1,0,2,1,1,1,1,0,1,1,
	1,0,0,0,1,0,4,4,4,1,
	1,0,2,1,1,0,0,1,0,1,
	1,0,2,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,0,0,1,
	1,1,1,1,1,1,1,1,1,1
};
int Map02[8][10]{
	1,1,1,1,1,1,1,1,1,1,
	1,0,3,0,0,0,0,0,0,1,
	1,1,2,1,1,1,1,0,1,1,
	1,4,4,4,1,0,0,0,0,1,
	1,0,2,1,1,0,1,1,1,1,
	1,2,0,0,0,0,0,0,0,1,
	1,0,0,0,0,0,0,0,0,1,
	1,1,1,1,1,1,1,1,1,1
};
int score = 0; 
struct fruits_post {
	int x;
	int y;
};
struct box_post {
	int x;
	int y;
};
struct Man_post {
	int x;
	int y;
};
fruits_post f[3];
box_post g[3];
void Menu();
void Ruls(int Map[][10], int& x, int& y) {	//�����ӵĹ���
	char userKey = _getch();
	
	int key = (int)userKey;
	
	if (key == 27)
		Menu();
			
	
	if (userKey == 'w' || userKey == 'W' || key == 72) {
		if (Map[y - 1][x] == 2)
			if (Map[y - 2][x] != 1 && Map[y - 2][x] != 2) {
				Map[y - 2][x] = Map[y - 1][x];
				Map[y - 1][x] = Map[y][x];
				Map[y][x] = 0;

				y = y - 1;
				++score;
			}
		if (Map[y - 1][x] != 1 && Map[y - 1][x] != 2) {

			Map[y - 1][x] = Map[y][x];
			Map[y][x] = 0;
			y = y - 1;
			++score;
		}
	}
	if (userKey == 's' || userKey == 'S' || key == 80) {
		if (Map[y + 1][x] == 2)
			if (Map[y + 2][x] != 1 && Map[y + 2][x] != 2) {
				Map[y + 2][x] = Map[y + 1][x];
				Map[y + 1][x] = Map[y][x];
				Map[y][x] = 0;

				y = y + 1;
				++score;
			}
		if (Map[y + 1][x] != 1 && Map[y + 1][x] != 2) {

			Map[y + 1][x] = Map[y][x];
			Map[y][x] = 0;
			y = y + 1;
			++score;
		}

	}
	if (userKey == 'a' || userKey == 'A' || key == 75) {
		if (Map[y][x - 1] == 2)
			if (Map[y][x - 2] != 1 && Map[y][x - 2] != 2) {
				Map[y][x - 2] = Map[y][x - 1];
				Map[y][x - 1] = Map[y][x];
				Map[y][x] = 0;

				x = x - 1;
				++score;
			}
		if (Map[y][x - 1] != 1 && Map[y][x - 1] != 2) {

			Map[y][x - 1] = Map[y][x];
			Map[y][x] = 0;
			x = x - 1;
			++score;
		}
	}
	if (userKey == 'd' || userKey == 'D' || key == 77) {
		if (Map[y][x + 1] == 2)
			if (Map[y][x + 2] != 1 && Map[y][x + 2] != 2) {
				Map[y][x + 2] = Map[y][x + 1];
				Map[y][x + 1] = Map[y][x];
				Map[y][x] = 0;

				x = x + 1;
				++score;
			}
		if (Map[y][x + 1] != 1 && Map[y][x + 1] != 2) {

			Map[y][x + 1] = Map[y][x];
			Map[y][x] = 0;
			x = x + 1;
			++score;
		}
	}
	
	if (Map[f[0].y][f[0].x] != 3 && Map[f[0].y][f[0].x] != 2)
		Map[f[0].y][f[0].x] = 4;
	if (Map[f[1].y][f[1].x] != 3 && Map[f[1].y][f[1].x] != 2)
		Map[f[1].y][f[1].x] = 4;
	if (Map[f[2].y][f[2].x] != 3 && Map[f[2].y][f[2].x] != 2)
		Map[f[2].y][f[2].x] = 4;
}

Man_post get_man_post(int Map[][10]) {						//��ȡ�˵�λ��
	Man_post m;
	for (int i = 0; i < 8; ++i) {
		for (int j = 0; j < 10; ++j) {

			if (Map[i][j] == 3) {
				m.x = j;
				m.y = i;
				return  m;
			}
		}
	}
}


void get_fruits_post(int Map[][10],fruits_post f[]) {			//�õ�����λ��
	int k=0;
	for (int i = 0; i < 8; ++i) {
		for (int j = 0; j < 10; ++j) {

			if (Map[i][j] == 4) {
				f[k].x = j;
				f[k].y = i;
				++k;
			}
		}
	}
				
}

void get_box_post(int Map[][10], box_post g[]) {			//�õ����ӵ�λ��
	int k = 0;
	for (int i = 0; i < 8; ++i) {
		for (int j = 0; j < 10; ++j) {

			if (Map[i][j] == 2) {
				g[k].x = j;
				g[k].y = i;
				++k;
			}
		}
	}

}
void traver_map(int Map[][10]) {							//����ͼ,������ͼ��
	IMAGE man, wall, backgroud, box, fruits;
	loadimage(&man, "����.jpg", 60, 60);
	loadimage(&wall, "ǽ.jpg", 60, 60);
	loadimage(&backgroud, "����.jpg", 60, 60);
	loadimage(&box, "����.jpg", 60, 60);
	loadimage(&fruits, "ˮ��.jpg", 60, 60);
	
	for (int i = 0; i < 8; ++i)
		for (int j = 0; j < 10; ++j) {						
			if (Map[i][j] == 0)								//0 ��ʾ����
				putimage(j * 60, i * 60, &backgroud);		
			if (Map[i][j] == 1)								//1 ��ʾǽ 
				putimage(j * 60, i * 60, &wall);
			if (Map[i][j] == 2)								//2 ��ʾ����
				putimage(j * 60, i * 60, &box);				
			if (Map[i][j] == 3)								//3 ��ʾ��
				putimage(j * 60, i * 60, &man);				
			if (Map[i][j] == 4)								//4 ��ʾ�ʻ�
				putimage(j * 60, i * 60, &fruits);
		}
	setbkcolor(WHITE);
	settextcolor(LIGHTBLUE);
	settextstyle(30, 10, "����");
	
	char str1[30] = {0};
	
	sprintf_s(str1, "��ESC�ص��˵�   ����:[%d]", score);
	
	
	outtextxy(0, 0, str1);
	//outtextxy(0, 0, str);
}
void map();
void map1();
void map2();
void chance();

void Menu() {						//�˵������趨
	IMAGE menu,chang;
	loadimage(&menu, "�˵�.jpg", 60*10, 60*8);
	
	setfillcolor(WHITE);
	POINT line_post[] = { {296,145},{280,155},{312,155} };
	POINT line_post1[] = { {296,260},{280,270},{312,270} };

	
	putimage(0, 0, &menu);
	MOUSEMSG m;
	while (1)
	{
		char str[12] = { 0 };
		m = GetMouseMsg();
	//	sprintf_s(str, "���� (%d,%d)", m.x, m.y);
		if (m.x < 378 && m.x>219 && m.y > 98 && m.y < 151) {
			solidpolygon(line_post, 3);
			if (m.uMsg == WM_LBUTTONDOWN) 
				 {
					map();
					map1();
					map2();
				}
			}
		
		else if (m.x < 378 && m.x>219 && m.y > 208 && m.y < 268) {
				solidpolygon(line_post1, 3);
				if (m.uMsg == WM_LBUTTONDOWN)
					chance();
					
			}
		else if (m.x < 111 && m.x>19 && m.y > 18 && m.y < 61) {
			if (m.uMsg == WM_LBUTTONDOWN)
				exit(0);
		}
		else
			putimage(0, 0, &menu);
	//	outtextxy(0, 0, str);
	}
}
void chance() {						//�ؿ�ѡ������趨
	IMAGE chang;
	loadimage(&chang, "�ؿ�.jpg", 60 * 10, 60 * 8);
	clearcliprgn();
	putimage(0, 0, &chang);
	while (1)
	{
		
		MOUSEMSG m;
		char str[20] = { 0 };
		m = GetMouseMsg();
		
	
		if (m.x < 203 && m.x>150 && m.y > 62 && m.y < 211) 
			if (m.uMsg == WM_LBUTTONDOWN) {
				map();
				map1();
				map2();
			}
		if(m.x < 304 && m.x>252 && m.y > 62 && m.y < 211)
			if (m.uMsg == WM_LBUTTONDOWN) {
				
				map1();
				map2();
			}
		if (m.x < 400 && m.x>344 && m.y > 62 && m.y < 211)
			if (m.uMsg == WM_LBUTTONDOWN) {

				map2();
			}
		if (m.x < 90 && m.x>20 && m.y > 18 && m.y < 50) 
			if (m.uMsg == WM_LBUTTONDOWN)
				Menu();
	//	if (m.x < 378 && m.x>219 && m.y > 98 && m.y < 151)
		
	}
}
void map() {											//��ͼ 1 ����
	int Map[8][10];
	for (int i = 0; i < 8; ++i) 
		for (int j = 0; j < 10; ++j) {
			Map[i][j] = Map00[i][j];
		}

	
	IMAGE nice, white, button, failure, again;
	loadimage(&nice, "ͨ��.jpg", 60 * 10, 60 * 8);
	loadimage(&failure, "ʧ��.jpg", 60 * 10, 60 * 8);
	traver_map(Map);
	get_fruits_post(Map, f);

	
	while (1) {

		Man_post m;
		m = get_man_post(Map);
		
		Ruls(Map, m.x, m.y);
	
		traver_map(Map);
	
		get_box_post(Map, g);
		if (g[0].x == 1 || g[0].x == 8 || g[0].y == 1 || g[0].y == 6 || (g[0].y == 3 && g[0].x == 3	)|| 	//�ж�3������λ���Ƿ��ʹ��Ϸʧ��
			g[1].x == 1 || g[1].x == 8 || g[1].y == 1 || g[1].y == 6 || (g[1].y == 3 && g[1].x == 3) ||
			g[2].x == 1 || g[2].x == 8 || g[2].y == 1 || g[2].y == 6 ||(g[2].y == 3 && g[2].x == 3)  )
		{
			putimage(0, 0, &failure);
			score = 0;        //��������
			//	putimage(60, 60, &again);
			MOUSEMSG m;
			while (1)
			{
				char str[20] = { 0 };
				m = GetMouseMsg();
				if (m.x < 390 && m.x>229 && m.y > 425 && m.y < 456)
					if (m.uMsg == WM_LBUTTONDOWN) {
						map();
						map1();
						map2();
					}
				if (m.x < 112 && m.x>19 && m.y > 16 && m.y < 50)
					if (m.uMsg == WM_LBUTTONDOWN)
						Menu();
			}
		}

		if (Map[f[0].y][f[0].x] == 2 && Map[f[1].y][f[1].x] == 2 && Map[f[2].y][f[2].x] == 2) {

			putimage(0, 0, &nice);
			getchar();
			break;
		}
	}
}
void map1() {
	int Map1[8][10];
	for (int i = 0; i < 8; ++i)
		for (int j = 0; j < 10; ++j) {
			Map1[i][j] = Map01[i][j];
		}
	IMAGE nice, white, button, failure, again;
	loadimage(&nice, "ͨ��.jpg", 60 * 10, 60 * 8);
	loadimage(&failure, "ʧ��.jpg", 60 * 10, 60 * 8);
	traver_map(Map1);
	get_fruits_post(Map1, f);
	score = 0;
	traver_map(Map1);
	while (1) {
		Man_post m;
		m = get_man_post(Map1);

		Ruls(Map1, m.x, m.y);

		traver_map(Map1);

		get_box_post(Map1, g);
		if (g[0].x == 1 ||  g[0].y == 1 || g[0].y == 6 || (g[0].y == 3 && g[0].x == 3) || 	//�ж�3������λ���Ƿ��ʹ��Ϸʧ��
			g[1].x == 1 ||  g[1].y == 1 || g[1].y == 6 || (g[1].y == 3 && g[1].x == 3) ||
			g[2].x == 1 ||  g[2].y == 1 || g[2].y == 6 || (g[2].y == 3 && g[2].x == 3) ||
			(g[0].x == 5 && g[0].y == 3) || (g[0].x == 5 && g[0].y == 4) ||
			(g[1].x == 5 && g[1].y == 3) || (g[1].x == 5 && g[1].y == 4) ||
			(g[2].x == 5 && g[2].y == 3) || (g[2].x == 5 && g[2].y == 4) )
		{
			putimage(0, 0, &failure);
			score = 0;        //��������
			
			MOUSEMSG m;
			while (1)
			{
				char str[20] = { 0 };
				m = GetMouseMsg();
				if (m.x < 390 && m.x>229 && m.y > 425 && m.y < 456)
					if (m.uMsg == WM_LBUTTONDOWN) {
						
						map1();
						map2();
					}
				if (m.x < 112 && m.x>19 && m.y > 16 && m.y < 50)
					if (m.uMsg == WM_LBUTTONDOWN)
						Menu();
			}
		}

		if (Map1[f[0].y][f[0].x] == 2 && Map1[f[1].y][f[1].x] == 2 && Map1[f[2].y][f[2].x] == 2) {

			putimage(0, 0, &nice);
			getchar();
			break;
		}
	}
}
void map2() {
	int Map2[8][10];
	for (int i = 0; i < 8; ++i)
		for (int j = 0; j < 10; ++j) {
			Map2[i][j] = Map02[i][j];
		}
	IMAGE nice, white, button, failure, again;
	loadimage(&nice, "ͨ��.jpg", 60 * 10, 60 * 8);
	loadimage(&failure, "ʧ��.jpg", 60 * 10, 60 * 8);
	traver_map(Map2);
	get_fruits_post(Map2, f);
	score = 0;
	traver_map(Map2);
	while (1) {
		Man_post m;
		m = get_man_post(Map2);

		Ruls(Map2, m.x, m.y);

		traver_map(Map2);

		get_box_post(Map2, g);
		if (g[0].x == 8 || g[0].y == 1 || g[0].y == 6 ||			//�ж�3������λ���Ƿ��ʹ��Ϸʧ��
			(g[1].x == 2 && g[1].y == 4 && g[0].x == 2 && g[0].y == 3) ||
			(g[2].x == 2 && g[2].y == 4 && g[1].x == 1 && g[1].y == 4) ||
			(g[2].x == 2 && g[2].y == 3 && g[1].x == 1 && g[1].y == 3) ||
			 g[1].x == 8 || g[1].y == 1 || g[1].y == 6 ||  g[2].x == 8 || g[2].y == 1 || g[2].y == 6  )
		{
			putimage(0, 0, &failure);
			score = 0;        //��������
			//	putimage(60, 60, &again);
			MOUSEMSG m;
			while (1)
			{
				char str[20] = { 0 };
				m = GetMouseMsg();
				if (m.x < 390 && m.x>229 && m.y > 425 && m.y < 456)
					if (m.uMsg == WM_LBUTTONDOWN) {
						
						
						map2();
					}
				if (m.x < 112 && m.x>19 && m.y > 16 && m.y < 50)
					if (m.uMsg == WM_LBUTTONDOWN)
						Menu();
			}
		}
		if (Map2[f[0].y][f[0].x] == 2 && Map2[f[1].y][f[1].x] == 2 && Map2[f[2].y][f[2].x] == 2) {
			putimage(0, 0, &nice);
			getchar();
			break;
		}
	}
	Menu();
}





int main(){
	
	initgraph(60*10, 60*8);
	
	Menu();
	
	closegraph();
	
	return 0;
}
